package application;
	
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;


public class Main extends Application {
	
	public enum operation {
		PLUS,
		MINUS,
		MULT,
		DIVISION
	}
	Float op_1;
	Float op_2;
	private operation op;
	boolean reset = false;

	@Override
	public void start(Stage primaryStage) {
		try {
			GridPane gridpane = new GridPane();
			
			
			
			
			TextField tf_nums = new TextField("0");
			
			Button btn_1 = new Button("1");
			btn_1.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_1.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("1");
					}else {
						String new_nums = curr_nums + "1";
						tf_nums.setText(new_nums);
					}
					
				}
			});
			
			Button btn_2 = new Button("2");
			btn_2.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_2.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("2");
					}else {
						String new_nums = curr_nums + "2";
						tf_nums.setText(new_nums);
					}
					
				}
			});
			
			Button btn_3 = new Button("3");
			btn_3.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_3.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("3");
					}else {
						String new_nums = curr_nums + "3";
						tf_nums.setText(new_nums);
					}
					
				}
			});
		
			Button btn_4 = new Button("4");
			btn_4.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_4.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("4");
					}else {
						String new_nums = curr_nums + "4";
						tf_nums.setText(new_nums);
					}
				}
			});
			
			Button btn_5 = new Button("5");
			btn_5.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_5.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("5");
					}else {
						String new_nums = curr_nums + "5";
						tf_nums.setText(new_nums);
					}
				}
			});
			
			Button btn_6 = new Button("6");
			btn_6.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_6.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("6");
					}else {
						String new_nums = curr_nums + "6";
						tf_nums.setText(new_nums);
					}
					
				}
			});
			
			Button btn_7 = new Button("7");
			btn_7.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			
			btn_7.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("7");
					}else{
						String new_nums = curr_nums + "7";
						tf_nums.setText(new_nums);
					}
				}
			});
			
			
			Button btn_8 = new Button("8");
			btn_8.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			
			btn_8.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("8");
					}else {
						String new_nums = curr_nums + "8";
						tf_nums.setText(new_nums);
					}
				}
			});
			
			Button btn_9 = new Button("9");
			btn_9.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			
			btn_9.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (curr_nums.equals("0")) {
						tf_nums.setText("9");
					}else {
						String new_nums = curr_nums + "9";
						tf_nums.setText(new_nums);
					}
					
				}
			});
			
			Button btn_0 = new Button("0");
			btn_0.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_0.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					if (reset == true) {
						tf_nums.setText("");
						reset = false;
					}
					String curr_nums = tf_nums.getText();
					if (!curr_nums.equals("0")) {
						System.out.println(curr_nums);
						String new_nums = curr_nums + "0";
						tf_nums.setText(new_nums);
					}
					if (curr_nums.equals("0")) {
						tf_nums.setText("0");
					}
					
					
				}
			});
			
			Button btn_plus = new Button("+");
			btn_plus.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_plus.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
							op_1 = Float.parseFloat(tf_nums.getText());
							op = operation.PLUS;
							tf_nums.setText("");
						
					
				}
			});
			
			Button btn_minus = new Button("-");
			btn_minus.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_minus.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
						op_1 = Float.parseFloat(tf_nums.getText());
						op = operation.MINUS;
						tf_nums.setText("");
				
				}
			});
			
			Button btn_mult = new Button("x");
			btn_mult.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_mult.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					op_1 = Float.parseFloat(tf_nums.getText());
					op = operation.MULT;
					tf_nums.setText("");	
				}
			});
			Button btn_div = new Button("/");
			btn_div.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_div.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					op_1 = Float.parseFloat(tf_nums.getText());
					op = operation.DIVISION;
					tf_nums.setText("");	
				}
			});
			
			
			Button btn_equals = new Button("=");
			btn_equals.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_equals.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					
					op_2 = Float.parseFloat(tf_nums.getText());
					
					Float result;
					String result_s;
					
					switch  (op) {
					
					case PLUS:
						result = op_1 + op_2;
						result_s = Float.toString(result);
						tf_nums.setText(result_s);
						op_1 = result;
						break;
						
					case MINUS:
						
						result = op_1 - op_2;
						result_s = Float.toString(result);
						tf_nums.setText(result_s);
						op_1 = result;
						break;
						
					case MULT:
						
						result = op_1 * op_2;
						result_s = Float.toString(result);
						tf_nums.setText(result_s);
						op_1 = result;
						break;
						
					case DIVISION:
						if (op_2 == 0.0) {
							tf_nums.setText("error");
							
						}else{
							result = op_1 / op_2;
							result_s = Float.toString(result);
							tf_nums.setText(result_s);
							op_1 = result;
						}
						break;	
						
						
					default:
						result =  null;
						result_s = Float.toString(result);
						tf_nums.setText(result_s);
						op_1 = result;
						break;
					}
					
					
					
					reset = true;
				}
			});
			
			Button btn_C = new Button("C");
			btn_C.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_C.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					tf_nums.setText("0");	
				}
			});
			
			
			Button btn_dot = new Button(",");
			btn_dot.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_dot.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					String curr_nums = tf_nums.getText();
					if (curr_nums.contains(".") == false) {
						if (curr_nums != "0") {
							String new_nums = curr_nums + ".";
							tf_nums.setText(new_nums);
						}else {
							tf_nums.setText("0.");
						}
					}
				}
			});
			
			Button btn_res = new Button("RES");
			btn_res.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			btn_res.setOnAction(new EventHandler<ActionEvent>() {
				
				public void handle (ActionEvent event) {
					op_2 = (float)0;
					op_1 = (float)0;
					tf_nums.setText("0");
				}
			});
			
			
			tf_nums.setEditable(false);
			tf_nums.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
			
			gridpane.setPadding(new Insets(10,10,10,10));
			gridpane.setVgap(9);
			gridpane.setHgap(9);
			gridpane.setAlignment(Pos.CENTER);
			
			gridpane.add(tf_nums, 0, 0, 5, 1);
			gridpane.add(btn_1, 0, 1);
			gridpane.add(btn_2, 1, 1);
			gridpane.add(btn_3, 2, 1);
			gridpane.add(btn_plus, 3, 1, 2, 1);
			gridpane.add(btn_4, 0, 2);
			gridpane.add(btn_5, 1, 2);
			gridpane.add(btn_6, 2, 2);
			gridpane.add(btn_minus, 3, 2, 2, 1);
			gridpane.add(btn_7, 0, 3);
			gridpane.add(btn_8, 1, 3);
			gridpane.add(btn_9, 2, 3);
			gridpane.add(btn_mult, 3, 3, 2, 1);
			gridpane.add(btn_C, 0, 4);
			gridpane.add(btn_0, 1, 4);
			gridpane.add(btn_equals, 2, 4);
			gridpane.add(btn_div, 3, 4, 2, 1);
			gridpane.add(btn_dot, 0 , 5, 2,1);
			gridpane.add(btn_res, 2, 5, 2, 1);
			
		
			Scene scene = new Scene(gridpane,300,250);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.setTitle("Calculator");
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
